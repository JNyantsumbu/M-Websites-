<?php
include './config/server.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service Delivery</title>
    <link rel="stylesheet" href="header.css">
    <?php
        
        include 'header.php';
    ?>

</head>
<body>
    <br>
    <h3>Public Access to Information</h3>
    <br>
    <p>The information on this website fulfils the City’s constitutional obligation, in terms of South Africa’s Promotion of Access to Information Act (No. 2 of 2000), to ensure transparency and accountability in its affairs, 
        and to ensure that that the public has effective access to information about the City and its governance.</p>
    <br>
</body>
<?php
          include 'footer.php';
      ?>
</html>