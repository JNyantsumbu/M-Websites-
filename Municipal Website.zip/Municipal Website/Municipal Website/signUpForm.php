<?php
  include './config/server.php';

  if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $id = $_POST['ID'];
    $password = $_POST['password'];
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    // Validate and sanitize user inputs
    $name = mysqli_real_escape_string($conn, $name);
    $email = mysqli_real_escape_string($conn, $email);
    $number = mysqli_real_escape_string($conn, $number);
    $id = mysqli_real_escape_string($conn, $id);
    $password = mysqli_real_escape_string($conn, $password);

    $query = "INSERT INTO `signup` (`id_number`, `full_names`, `phone_number`, `email`, `password`) VALUES ('$id', '$name', '$number', '$email', '$hashedPassword')";

    $results = mysqli_query($conn, $query);

    if($results){
        echo "submitted";

    }
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign up</title>
    <link rel="stylesheet" href="formStyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="signUp">
        <div class="form">
            <form class="registrationForm" action="validatesignup.php"method="POST" onsubmit="return validateForm()">
                <h1>Sign Up</h1>
                <input type="text" name="name" placeholder="Name(s) & Surname">
                <span class="error"><?php echo isset($errors['name']) ? $errors['name'] : ''; ?></span>
                <br>
                <input type="text" name="email" placeholder="Email">
                
                <br>
                <input type="text" name="number" placeholder="Phone number">
                <br>
                <input type="text" name="ID" placeholder="ID number">
                <br>
                <input type="password" name="password" placeholder="Password">
                <br>
                <input type="password" name="password2" placeholder="Confirm Password">
                <br>
                <button type="submit" name="submit" id="btn">Create profile</button>
                <br>
                <span class="question">Already Registered? <a href="loginForm.php">Login</a></span>
            </form>
        </div>
    </div>
   
</body>
</html>
<script>
    function validateForm() {
    var name = document.getElementById("name").value;
    var email = document.getElementById("email").value;
    var number = document.getElementById("number").value;
    var ID = document.getElementById("ID").value;
    var password = document.getElementById("password").value;
    var password2 = document.getElementById("password2").value

    var nameError = document.getElementById("nameError");
    var emailError = document.getElementById("emailError");
    var numberError = document.getElementById("numberError");
    var IDError = document.getElementById("IDError");
    var passwordError = document.getElementById("passwordError");
    var password2Error = document.getElementById("password2Error");

    nameError.textContent = "";
    emailError.textContent = "";
    numberError.textContent = "";
    IDError.textContent = "";
    passwordError.textContent = "";
    password2Error.textContent = "";
    }
    var isValid = true;

    if (name.trim() === "") {
        nameError.textContent = "Please enter your name";
        isValid = false;
    }

    if (email.trim() === "") {
        emailError.textContent = "Please enter your email";
        isValid = false;
    }

    if (number.trim() === "") {
        numberError.textContent = "Please enter your phone number";
        isValid = false;
    } else if (!/^\d{10}$/.test(number)) {
        numberError.textContent = "Phone number must be 10 digits";
        isValid = false;
    }
    if (ID.trim() === "") {
        IDError.textContent = "Please enter your ID";
        isValid = false;
    } else if (!/^\d{13}$/.test(ID)) {
        IDError.textContent = "ID number must be 13 digits";
        isValid = false;
    }

    if (password.trim() === "") {
        passwordError.textContent = "Please enter your password";
        isValid = false;
    }

    if (password2.trim() === "") {
        password2Error.textContent = "Please confirm your password";
        isValid = false;
    }
    if (password !== password2) {
        password2Error.textContent = "Passwords do not match";
        isValid = false;
    }

    return isValid;
</script>



