<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="footer.css">
    <title>Footer</title>
</head>
<body>
    <footer class="footer">
        <div class="container">
            <div class="footerRows">
                <div class="column">
                    <div class="logo"><i></i>Municipal</div>
                    <span id="summary">       
                        Municipal is a startup website made by second year students at the University of Johannesburg.municipality is usually a single administrative division having corporate status and powers of self-government or jurisdiction as granted by national and regional laws to which it is subordinate.
    We are aware of the problem we have been facing regarding fault with electricity, water, sewerage, refuse removal, unemployment and job searching in general, and we want fill that void.
                    </span>
                </div>
                <div class="column">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="service_delivery.php">Service delivery</a></li>
                        <li><a href="CVcreation.php">Recruitment</a></li>
                        <li><a href="pay_utilities.php">Pay for water and electricty</a></li>
                      
                    </ul>
                </div>
                
                <div class="column">
                    <h4>follow us</h4>
                    <div class="links">
                        <a href="https://www.facebook.com/photo/?fbid=586082506887512&set=a.147185734110527"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a> 				
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>


