
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Frequently Asked Questions</title>
    <link rel="stylesheet" href="header.css">
    <?php
        
        include 'header.php';
    ?>
</head>
<body>
    <h2>Frequently Asked Questions</h2>
    <br>
    <h4>What are Municipal By-Laws?</h4>
    <br>
    <p>Municipal by-laws are laws that are passed by the Council of a municipality to regulate the affairs and the services the municipality it provides in its area of jurisdiction. 
        A municipality derives the power to pass by-laws from the Constitution of the Republic of South Africa, 1996, which gives specified powers and competencies to local government.
         The main function of by-laws is to ensure that a city is orderly to live and work in.
    </p>
    <br>
    <h4>How Much deos it cost to install a prepaid Meter?</h4>
    <br>
    <p>R425 is the cost for the meter itself. The installation of the backing plate has to be done by an 
        electrician of your own choice (cost to be paid by the consumer), who will issue a compliance certificate. </p>
    <br>
    <h4>How much is a deposit for a conventional meter and prepaid meter?</h4>
    <br>
    <p>For conventional meters, the cost is R450. No deposit is required for a prepaid meter. </p>
    <br>
    <h4>Electricity Saving tips in and arround the house</h4>
    <br>
    <p>Switch off the lights when not in use and when leaving the room. <br>
    Use low energy lamps for exterior lighting with timer or light sensor for switching.
    <br>Use energy saving bulbs (fluorescent lights), they could save you a huge amount of money and they last longer compared to the incandescent lights.
    <br>
    Reduce the temperature of your geyser to around 55 degrees, so that you don’t need to add much cold water when you shower or do the dishes. <br>
    </p>    
    <br>
    <h4>What do i need to do when I move out of a house, a flat or a business site</h4><br>
    <p>Take your ID with you to your nearest municipal enquiries office. You will be asked the address of the property you plan to vacate and the date on which you wish to have your services disconnected. <br>
    This has to be done at least four workings days prior to the date on which you want the services terminated
    </p>
</body>
</html>