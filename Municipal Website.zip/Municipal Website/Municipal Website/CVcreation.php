<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Municipal | Recruitment</title>
    <link rel="stylesheet" href="Candidate_profileStyle.css">
    <link rel="Stylesheet" href="Recruitment.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/da7a0ef97e.js" crossorigin="anonymous"></script>
<?php
        
        include 'header.php';
    ?>
</head>
<body>
    <div class="main">
        
        <main>
            <h1>How to Create a Curriculum Vitae (CV)</h1>
            <br>
            <p>
                In order to ensure that your employer can see a brief overview of who you are, a Curriculum Vitae is created. this will allow 
                your potential employer to see who you are at a glance and gain a preliminary understanding on whether or not you would be a good
                fit for the business. Due to the fact that CV's contain brief information about you and that employers have to go through potentially 100s
                of different CV's, sometimes daily, it is important that you create a CV that is concise and eye-catching in order for yours to stand out above all the rest.
                This is where we here at GRAD can help with inspiring templates as well as instructions on how to create an amazing CV.
                <br>
                <br>
                <h2>Creating Your CV</h2>
                <br>
                In order to create an eye-catching Curriculum Vitae just follow our steps and tips.<br>
                <h3>Select a Template</h3>
                Choose a template that you believe will best catch the eyes of the HR manager who will be looking at your CV. Choose 
                something that both looks good and professional. We provide a link to a website which we believe has some amazing templates 
                to choose from or you can search the internet.
                for even more options.
                <br>
                <h3>Add all of your contact information</h3>
                This may arguably be the most important step because no matter how great or eye-catching your CV ends up being, 
                if your contact information is wrong then the employer will have no way of contacting you. So in the section of 
                your template that houses the contact information, make sure that you add the most up-to-date contact information, 
                after all you wouldn't want to miss a job just because they could not contact you.
                <br>
                <h3>Grab the HR manager’s attention with a CV summary or objective</h3>
                A CV summary is the part of the CV where in a short amount for time you HAVE to sell yourself to your potential 
                employer. A CV summary is a small description of you and your skills/experience, this short summary is the first 
                impression that they will have of you so ensure it is good. Make sure that it is clear and concise.
                <br>
                <h3>Display all of your work experience</h3>
                This is an important part part of your CV as it will allow your potential employer to be aware of all the working 
                experience you have accumulated over your working career, if any at all.
                <br>
                <h3>Include all of your relevant skills within your CV</h3>
                This is where you will be able to display just how skilled you are. And in this section DO NOT be shy to boast a 
                little bit. Sell your self as much as possible after all an employer will love an employee who ahs a versatile set of skills.
                <br>
                <h3>Include all of your education in your CV</h3>
                Here you want to display where it is that you received your FORMAL education. This means tertiary education in most instances 
                however high school can also work depending on where you are applying.
                <br>
                <h3>Include other sections</h3>
                Remember that this is supposed to tell the employer all about you so add a few extra sections with brief/concise info like hobbies.
                REMEMBER this is supposed to be a brief overview of you so DO NOT put to many unnecessary sections, generally CV templates will 
                provide extra sections that may be useful to know to the employer so just stick to those.
                <br>
                <br>

                <h2>Things to keep in mind when creating a CV</h2>
                When filling in the sections, always keep in mind the gold CV formatting rules: <br>
                <h3>Choose clear, legible fonts</h3>
                Go for one of the standard CV typefaces: Arial, Tahoma, or Helvetica if you prefer sans-serif fonts, and Times New Roman or Bookman Old Style if serif fonts are your usual pick. <br>
                Use 11 to 12 pt font size and single spacing. For your name and section titles, pick 14 to 16 pt font size. <br>
                <h3>Be consistent with your CV layout</h3>
                Set one-inch margins for all four sides. <br>
                Make sure your CV headings are uniform—make them larger and in bold but go easy on italics and underlining. <br>
                Stick to a single dates format on your CV: for example 11-2017, or November 2017. <br>
                <h3>Don’t cram your CV with gimmicky graphics</h3>
                Less is more. <br>
                White space is your friend—recruiters need some breathing room! <br>
                Plus, most of the time, after you send out your CV, it’s going to be printed in black ink on white paper. Too many graphics might make it illegible. <br>
                <h3>Get photos off of your CV</h3>
                Unless you’re explicitly asked to include your photograph in the job ad. <br>
                If so—make sure to use a professional looking picture, but not as stiff as an ID photo. <br>
                <h3>Make your CV brief and relevant </h3>
                Don’t be one of those candidates stuck in the nineties who think they have to include every single detail about their lives on their CVs. <br>
                <br>
                Here we also provided some videos to help best understand how to create a cv
                <br>
                <br>
                <iframe width="560" height="315" src="https://www.youtube.com/embed/_fP43gcBywU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                <br>
                <br>
                <iframe width="560" height="315" src="https://www.youtube.com/embed/k7KSx3g1OPI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </p>

        </main>
        <footer class="footer">
            <div class="container">
                <div class="footerRows">
                    <div class="column">
                        <div class="logo"><i></i>Municipal</div>
                        <span id="summary">       
                           
                        </span>
                    </div>
                    <div class="column">
                        <h4>Quick Links</h4>
                        <ul>
                            <li><a href="index.php">Home</a></li>
                            <li><a href="CVcreation.php">Recruitment</a></li>
                            <li><a href="service_delivery.php">Service delivery</a></li>
                            <li><a href="pay_utilities.php">Pay for water and electricty</a></li>
                       
                        </ul>
                    </div>
                    
                    <div class="column">
                        <h4>follow us</h4>
                        <div class="links">
                            <a href="https://www.facebook.com/photo/?fbid=586082506887512&set=a.147185734110527"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a> 				
                        </div>
                    </div>
                </div>
            </div>
        </footer>
</body>
</html>