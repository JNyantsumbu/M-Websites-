<?php
  include './config/server.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Municipal Website</title>
    <link rel="stylesheet" href="homepage.css">
    <link rel="stylesheet" href="header.css">
    <link rel="stylesheet" href="footer.css">
    <?php
        
        include 'header.php';
    ?>
</head>
<body>
  
    <div class="container1">
        
      </div>

      <section class="section description">
        <h2>Municipal</h2>
        <p>
        Welcome to the official of Municipal! Explore our site to learn about community Service.
        <br/>
        We are Commited to providing transparent and accessible Municipal services to our community.
        <br>
        This Website serves as a gateway for residents to be able to do their Municipal activities anywhere by signing in to our website.
        
        We hope that our website serves as a valuable tool for you to stay informed and engaged with you local municipality.
        </p>
         
    </section>
    
    <div class="container2">
      
      </div>  
      <?php
          include 'footer.php';
      ?>
    
</body>

</html>
