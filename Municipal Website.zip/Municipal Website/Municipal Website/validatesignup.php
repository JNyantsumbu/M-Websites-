<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Retrieve the form values
  $name = $_POST["name"];
  $email = $_POST["email"];
  $number = $_POST["number"];
  $ID = $_POST["ID"];
  $password = $_POST["password"];
  $password2 = $_POST["password2"];

  // Initialize an array to store the error messages
  $errors = array();

  // Perform validation checks
  if (empty($name)) {
    $errors["name"] = "Please enter your name and surname.";
  }

  if (empty($email)) {
    $errors["email"] = "Please enter your email.";
  }

  if (empty($number)) {
    $errors["number"] = "Please enter your phone number.";
  }

  if (empty($ID)) {
    $errors["ID"] = "Please enter your ID.";
  }

  if (empty($password)) {
    $errors["password"] = "Please enter your password.";
  }

  if ($password !== $password2) {
    $errors["password2"] = "Passwords do not match.";
  }

  // If there are any validation errors, display them
  if (!empty($errors)) {
    foreach ($errors as $field => $error) {
      echo "<p style='color: red;'>$error</p>";
    }
  } else {
    // All validation passed
    echo "Your Sign Up was Successful!";
    echo " ";
    echo "You can now login";
    

    // Additional processing or database operations can be performed here
  }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Validated</title>
</head>
<body>
  <br>
  <br>
<a href="loginForm.php">Login</a>
</body>
</html>
