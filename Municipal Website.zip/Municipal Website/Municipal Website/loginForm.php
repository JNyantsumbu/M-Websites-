<?php
session_start();
include './config/server.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Perform input validation
    if (empty($username) || empty($password)) {
        echo "Please enter both username and password.";
    } else {
        // Validate the username and password against your database or any other authentication mechanism
        // Assuming you have a table named 'users' with 'username' and 'password' columns

        $query = "SELECT * FROM signup WHERE email = '$username'";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            $storedPassword = $row['password'];

            // Verify the password
            if (password_verify($password, $storedPassword)) {
                // Authentication successful
                $_SESSION['username'] = $username;
                echo "Login successful. Welcome, " . $username;
                header("Location: index.php");
                exit; // Add this line to stop further execution of the script
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "Invalid username.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="formStyle.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="userlogin">
        <div class="form">
            <form class="login" method="POST">
                <h1>Login</h1>
                <input type="text" name="username" placeholder="Username(email)">
                <input type="password" name="password" placeholder="Password">
                <button type="submit" id="btn2">Login</button>
                <p class="question1">Not Registered? <a href="signUpForm.php">Sign Up</a></p>
                <br>
                <p>Forgot Password? <a href="forgot.php">Click Here</a></p>
            </form>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
