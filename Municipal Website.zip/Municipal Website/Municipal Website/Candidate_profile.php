<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="Candidate_profileStyle.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
<script src="https://kit.fontawesome.com/da7a0ef97e.js" crossorigin="anonymous"></script>
</head>
<body>
    <div class="container">
        <div class="main">

            <div class="dashboard">
                <h3>Candidate's Dashboard</h3>
            </div>

            <hr>

            <div class="head">
                <span>You can edit, remove your C.V & pay for water and electricity below:</span>
            </div>

            <div class="form">
                <div class="formContent">
                    <form action="">
                        <table>
                            <tr>
                                <th style="width:19% ;">Full Names</th>
                                <th>Title</th>
                                <th style="width:35% ;">Location/Address</th>
                                <th>Uploaded CV</th>
                                <th>Date Posted</th>
                            </tr>
                            <tr>
                                <td><input type="text" id="fullName" size="28px"></td>
                                <td><input type="text" id="Title" size="23px"></td>
                                <td><input type="text" id="Address" size="59px"></td>
                                <td><input type="text" id="Uploaded"></td> <!--PHP File upload-->
                                <td><input type="text" id="Date"></td>
                            </tr>
                            <tr>
                                <th style="width:19% ;">Full Names</th>
                                <th style="width:35% ;">Location/Address</th>
                                <th>Uploaded payment document for water and electricity</th>
                                <th>Date Posted</th>
                            </tr>
                            <tr>
                                <td><input type="text" id="fullName" size="28px"></td>
                                <td><input type="text" id="Address" size="59px"></td>
                                <td><input type="text" id="Uploaded"></td> <!--PHP File upload-->
                                <td><input type="text" id="Date"></td>
                            </tr>
                        </table>
                        <input type="submit" id="update" value="UPDATE">
                    </form>
                </div>
            </div>

            <div class="formSearch">
                <hr id="line">
                <div class="search">
                    <div class="job">Search for a job below:</div>
                    <form action="" >
                        <input type="text" id="searching" name="search" placeholder="Search...">
                    </form>
                </div>
            </div>
            <div class="formSearch">
                <hr id="line">
                <div class="search">
                    <div class="job">Report a fault:</div>
                    <form action="" >
                        <input type="text" id="searching" name="search" placeholder="Report...">
                    </form>
                </div>
            </div>

            <footer class="footer">
                <div class="container">
                    <div class="footerRows">
                        <div class="column">
                            <div class="logo"><i></i>Municipal</div>
                            <span id="summary">       
                                

                            </span>
                        </div>
                        <div class="column">
                            <h4>Quick Links</h4>
                            <ul>
                                <li><a href="index.php">Home</a></li>
                                <li><a href="">Service delivery</a></li>
                                <li><a href="Candidate_profile.php">Recruitment</a></li>
                                <li><a href="#">Pay for water and electricty</a></li>
                            </ul>
                        </div>
                       
                        <div class="column">
                            <h4>follow us</h4>
                            <div class="links">
                                <a href="#"><i class="fab fa-facebook-f"></i></a>
                                <a href="#"><i class="fab fa-twitter"></i></a>
                                <a href="#"><i class="fab fa-instagram"></i></a> 				
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>
</body>
</html>