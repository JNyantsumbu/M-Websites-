-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 30, 2023 at 12:39 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `signin`
--

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `idUser` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `reportproblem`
--

CREATE TABLE `reportproblem` (
  `id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `surname` int(11) NOT NULL,
  `location` int(11) NOT NULL,
  `cellnumber` int(11) NOT NULL,
  `fault` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `id_number` int(13) NOT NULL,
  `full_names` varchar(255) NOT NULL,
  `phone_number` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`id_number`, `full_names`, `phone_number`, `email`, `password`) VALUES
(45678, 'kwanlee', 456789, 'dajhsa', '1234'),
(0, 'Amahle', 0, 'amahle@gmail.com', '$2y$10$c5A6lC8kAD7WPNcKFKai7OAZk5n3GgmfdnnY06UrVEo.1HC1IExmG'),
(9876, 'Nhlakx', 1234, 'nhlkax@gmail', '$2y$10$CbHqALckNqON0vAj0uzkW.biw7cBwcDzJTC.guiW6QQ8x.Ixsm.d6'),
(94, 'nhlaka', 987, 'nhlaka@gmail', '$2y$10$uyIFLTd52eQXQO9DteS9jOqYVKo9FGi1fSWwJQI6liTR.l54vcNJm'),
(12313, 'nhlakx', 7233, 'nhlaka2', '$2y$10$yHnweZSKFAfMTyZoHTxLf.AekccrvW6o/u6kQyZbqKn/hAYjKg9sm'),
(2656, 'nhlakk', 344, 'whitemountain3310@gmail.com', '$2y$10$tUWD2A8vdXWR2c5w/DsFFe3di05q8jd529ALdr.HrudhHdbSlpURK'),
(0, '', 0, '', '$2y$10$qsR9His1ocwoeFVXJcM5N.w9rRSutKjbJURQ/bouP1pWTTy5jMKQe'),



--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`idUser`);

--
-- Indexes for table `reportproblem`
--
ALTER TABLE `reportproblem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `idUser` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reportproblem`
--
ALTER TABLE `reportproblem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
