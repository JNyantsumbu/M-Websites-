<?php
  include './config/server.php';
  if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $location= $_POST['location'];
    $number = $_POST['number'];
    $fault = $_POST['fault'];
    

    $query = "INSERT INTO `reportproblem` (`name`, `surname`, `location`, `cellnumber`, `fault`) VALUES ( '$name', '$surname','$location', '$number', '$fault')";

    $results = mysqli_query($conn, $query);

    if($results){
        echo "submitted";

        
    }
  }


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report a Problem</title>
    <link rel="stylesheet" href="reportproblem.css">
    <link rel="stylesheet" href="header.css">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
    <?php
        
        include 'header.php';
    ?>
</head>
<body>
    <div class="reportform">

    </div>
    <h2>Report a Problem</h2>

    <form action="" onsubmit="return validateForm()">
        <label for="">Name:</label><br>
        <input type="text" name="name"><br>
        <br>
        <label for="">Surname:</label><br>
        <input type="text" name="surname"><br>
        <br>
        <label for="">Fault Address/Residential Address/Location:</label><br>
        <input type="text" name="location"><br>
        <br>
        <label for="">Contact Number:</label><br>
        <input type="text" name="cellnumber"><br>
        <br>
        <label for="">Description of the Fault:</label><br>
        <input type="text" name="fault"><br>        
        <br>
        <input type="submit" name="submit" value="Submit">

    </form>

</body>
  <?php
  include 'footer.php';
  ?>
</html>
<script>
    function validateForm() {
        var name = document.getElementById("name").value;
        var surname = document.getElementById("surname").value;
        var location = document.getElementById("location").value;
        var cellnumber = document.getElementById("cellnumber").value;
        var fault = document.getElementById("fault").value;

        if (name === "" || surname === "" || location === "" || cellnumber === "" || fault === "") {
            alert("Please fill in all fields.");
            return false;
        }

        return true;
    }
</script>