<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="header.css">
    <title>Header</title>
</head>
<body>
<header>
    <nav>
        <div class="logo"><i></i>Municipal</div>
        <ul class="navLinks"> 
            <li><a href="index.php" >HOME</a></li>
            <li><a href="pay_utilities.php">Pay Utility Rates</a></li>
            <li><a href="CVcreation.php">Recruitment</a></li>
            <li><a href="service_delivery.php">Service delivery</a></li>
            <li><a href="reportproblem.php">Report a Problem</a></li>
            <li><a href="FAQ.php">FAQ</a></li>
        </ul>
        
        <?php
        if (isset($_SESSION['username'])) {
            // User is logged in, hide the login and signup buttons
            echo '<div class="loggedIn">
                      <span>Welcome, ' . $_SESSION['username'] . '</span>
                      <a href="loginForm.php">
                      <button>Logout</button>
                      </a>
                  </div>';
        } else {
            // User is not logged in, display the login and signup buttons
            echo '<div class="signUp">
                      <a href="signUpForm.php">
                        <button>Sign Up</button>
                      </a>
                  </div>
                  <div class="logIn">
                      <a href="loginForm.php">
                        <button>Login</button>
                      </a>
                  </div>';
        }
        ?>

    </nav>
</header>

</body>
</html>
